# 🏥 Pi Character Clinic

**The ultimate medical hub for gaming characters on Pi Network.**

Built by @scephask · Powered by Pi Network & Claude AI

## Features
- 🎮 Cross-game character import (CiDi, Free Fire, Genshin, PUBG & more)
- 📸 AI-powered screenshot stat reader for CiDi
- 🏆 Daily, Monthly & All-Time leaderboards with Pi rewards
- ⭐ Premium subscription (3π/month)
- 💊 Healing shop with Pi payments
- 🩺 AI Doctor powered by Claude

## Live App
[pi-character-clinic.vercel.app](https://pi-character-clinic.vercel.app)

## Setup
No setup needed — deployed via Vercel.

For AI Doctor, add your Anthropic API key in Vercel:
```
Settings → Environment Variables → REACT_APP_ANTHROPIC_KEY
```
